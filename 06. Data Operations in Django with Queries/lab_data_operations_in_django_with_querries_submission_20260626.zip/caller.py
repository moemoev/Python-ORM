import os
import django
from datetime import date

from django.db.models.functions import Replace

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
# Run and print your queries

from main_app.models import Employee, Student
from django.db import connection, reset_queries
from pprint import pp


# note: lab 01_add_students

# def add_students():
#     student_1 = Student(
#         student_id = "FC5204",
#         first_name = "John",
#         last_name = "Doe",
#         birth_date = "1995-05-15",
#         email = "john.doe@university.com"
#     )
#     student_1.save()
#
#     student_2 = Student(
#         student_id = "FE0054",
#         first_name = "Jane",
#         last_name = "Smith",
#         email = "jane.smith@university.com"
#     )
#     student_2.save()
#
#     student_3 = Student()
#     student_3.student_id = "FH2014"
#     student_3.first_name = "Alice"
#     student_3.last_name = "Johnson"
#     student_3.birth_date = "1998-02-10"
#     student_3.email = "alice.johnson@university.com"
#     student_3.save()
#
#     Student.objects.create(
#         student_id="FH2015",
#         first_name="Bob",
#         last_name="Wilson",
#         birth_date="1996-11-25",
#         email="bob.wilson@university.com"
#     )

#note: usage of bulk_:create

# def add_students():
#     student_list = [
#         Student(
#             student_id = "FC5204",
#             first_name = "John",
#             last_name = "Doe",
#             birth_date = "1995-05-15",
#             email = "john.doe@university.com"
#         ),
#         Student(
#             student_id = "FE0054",
#             first_name = "Jane",
#             last_name = "Smith",
#             email = "jane.smith@university.com"
#         ),
#         Student(
#         student_id = "FH2014",
#         first_name = "Alice",
#         last_name = "Johnson",
#         birth_date = "1998-02-10",
#         email = "alice.johnson@university.com"
#         ),
#         Student(
#             student_id="FH2015",
#             first_name="Bob",
#             last_name="Wilson",
#             birth_date="1996-11-25",
#             email="bob.wilson@university.com"
#         )
#     ]
#
#     Student.objects.bulk_create(student_list)
#
# add_students()
# pp(connection.queries)

# note: lab 02_get_students_info

# def get_students_info():
#     students = Student.objects.all()
#     f_stream = f"\n".join(f"Student №{student.student_id}: {student.first_name} {student.last_name}; Email: {student.email}"for student in students)
#
#     return f_stream

# print(get_students_info())
# pp(connection.queries)

from django.db.models import F

# def update_students_emails():
#     old_mail_domain = '@university.com'  # to change back for testing several realizations
#     new_mail_domain = '@uni-students.com'
#     students = Student.objects.all()
#
#     for s in students:
#         s.email = s.email.split('@')[0] + new_mail_domain
#
#     Student.objects.bulk_update(students,['email'])

# update_students_emails()
# pp(connection.queries)

def truncate_students():
    students = Student.objects.all()
    students.delete()

truncate_students()
pp(connection.queries)