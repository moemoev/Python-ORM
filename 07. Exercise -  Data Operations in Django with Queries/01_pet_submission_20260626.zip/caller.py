import os
import django
from django.db.models import Model

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Pet
# Create queries within functions

def create_pet(name: str, species:str):
    # pet = Pet(name=name, species=species)
    # pet.save()
    #
    pet = Pet.objects.create(name=name, species=species)

    return f"{pet.name} is a very cute {pet.species}!"

# print(create_pet('Rocky', 'Hamster'))