import os
import django
from django.db.models import Model

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Pet, Artifact
# Create queries within functions

#note: 01_pet
# def create_pet(name: str, species:str):
#     # pet = Pet(name=name, species=species)
#     # pet.save()
#     #
#     pet = Pet.objects.create(name=name, species=species)
#
#     return f"{pet.name} is a very cute {pet.species}!"

# print(create_pet('Rocky', 'Hamster'))

#note: 02_artifact
def create_artifact(name: str, origin: str, age: int, description: str, is_magical: bool) -> str:
    artifact = Artifact.objects.create(
        name=name,
        origin=origin,
        age=age,
        description=description,
        is_magical=is_magical
    )

    return f"The artifact {artifact.name} is {artifact.age} years old!"

def rename_artifact(artifact: Artifact, new_name: str):
    if artifact.age > 250 and artifact.is_magical:
        artifact.name = new_name
        artifact.save()

def delete_all_artifacts() -> None:
    artefacts = Artifact.objects.all()
    artefacts.delete()

# print(create_artifact('Ancient Sword', 'Lost Kingdom', 500, 'A legendary sword with a rich history', True))#
# artifact_object = Artifact.objects.get(name='Ancient Sword')
# rename_artifact(artifact_object, 'Ancient Shield')
# print(artifact_object.name)