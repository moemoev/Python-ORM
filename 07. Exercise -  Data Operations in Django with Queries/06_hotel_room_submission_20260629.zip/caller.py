import os
import django
from django.db.models import Model

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Pet, Artifact, Location, Car, Task, HotelRoom


# Create queries within functions

#note: 01_pet
# def create_pet(name: str, species:str):
#     # pet = Pet(name=name, species=species)
#     # pet.save()
#     #
#     pet = Pet.objects.create(name=name, species=species)
#
#     return f"{pet.name} is a very cute {pet.species}!"

# print(create_pet('Rocky', 'Hamster'))

#note: 02_artifact

# def create_artifact(name: str, origin: str, age: int, description: str, is_magical: bool) -> str:
#     artifact = Artifact.objects.create(
#         name=name,
#         origin=origin,
#         age=age,
#         description=description,
#         is_magical=is_magical
#     )
#
#     return f"The artifact {artifact.name} is {artifact.age} years old!"
#
# def rename_artifact(artifact: Artifact, new_name: str):
#     if artifact.age > 250 and artifact.is_magical:
#         artifact.name = new_name
#         artifact.save()
#
# def delete_all_artifacts() -> None:
#     artefacts = Artifact.objects.all()
#     artefacts.delete()

# print(create_artifact('Ancient Sword', 'Lost Kingdom', 500, 'A legendary sword with a rich history', True))#
# artifact_object = Artifact.objects.get(name='Ancient Sword')
# rename_artifact(artifact_object, 'Ancient Shield')
# print(artifact_object.name)

#note: 03_location

# def show_all_locations():
#     location = Location.objects.order_by("-id")
#
#     locations_list = [f"{l.name} has a population of {l.population}!" for l in location]
#
#     return "\n".join(locations_list)
#
# def new_capital():
#     location = Location.objects.first()
#     location.is_capital = True
#
#     location.save()
#
# def get_capitals():
#     capitals = Location.objects.filter(is_capital=True)
#
#     return capitals.values('name')
#
# def delete_first_location():
#     location = Location.objects.first()
#     location.delete()

# print(show_all_locations())
# print(new_capital())
# print(get_capitals())

#note: 04_car

# def calc_discount(digits: str):
#     result = 0
#     for d in digits:
#         result+= int(d)
#
#     return result
#
# def apply_discount() -> None:
#     car = Car.objects.all()
#
#     for c in car:
#         val = str(c.year)
#         discount = calc_discount(val)
#         c.price_with_discount = c.price - c.price * discount / 100
#
#     Car.objects.bulk_update(car, ["price_with_discount"])
#
# def get_recent_cars():
#     car = Car.objects.filter(year__gt=2020)
#
#     return car.values('model', 'price_with_discount')
#
#
# def delete_last_car():
#     car = Car.objects.last()
#     car.delete()


# apply_discount()
# print(get_recent_cars())
# delete_last_car()

#note: 05_task_encoder
#
# def show_unfinished_tasks() -> str:
#     tasks = Task.objects.filter(is_finished=False)
#
#     unfished_tasks = [f"Task - {t.title} needs to be done until {t.due_date}!" for t in tasks]
#
#     return "\n".join(unfished_tasks)
#
# def complete_odd_tasks()-> None:
#     tasks = Task.objects.all()
#     odd_tasks = []
#
#     for t in tasks:
#         if t.id % 2 == 1:
#             t.is_finished = True
#             odd_tasks.append(t)
#
#     Task.objects.bulk_update(odd_tasks, ["is_finished"])
#
# def cipher_text(text:str) -> str:
#     result = ''
#     for ch in text:
#         result += chr(ord(ch) - 3)
#
#     return result
#
# def encode_and_replace(text: str, task_title: str):
#     encoded_text = cipher_text(text)
#
#     tasks = Task.objects.filter(title=task_title)
#
#     for t in tasks:
#         t.description = encoded_text
#
#     Task.objects.bulk_update(tasks, ['description'])

# encode_and_replace("Zdvk#wkh#glvkhv$", "Sample Task")
# print(Task.objects.get(title='Sample Task').description)
#complete_odd_tasks()

#note: 06_hotel_room

def get_deluxe_rooms():
    rooms = HotelRoom.objects.filter(room_type="Deluxe")

    even_rooms = []
    for r in rooms:
        if r.id % 2 == 0:
            even_rooms.append(r)

    return "\n".join(f"Deluxe room with number {r.room_number} costs {r.price_per_night}$ per night!" for r in even_rooms)

def increase_room_capacity():
    rooms = HotelRoom.objects.order_by("id")
    key = 0

    for r in rooms:
        if r.is_reserved:
            if r.id == 1:
                r.capacity += 1
            else:
                r.capacity += key

        key = r.capacity

    HotelRoom.objects.bulk_update(rooms, ['capacity'])

def reserve_first_room():
    room = HotelRoom.objects.get(id=1)
    room.is_reserved = True
    room.save()

def delete_last_room():
    room = HotelRoom.objects.last()

    if not room.is_reserved:
        room.delete()
