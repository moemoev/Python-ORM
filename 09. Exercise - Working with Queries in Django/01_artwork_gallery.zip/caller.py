import os
import django



# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from django.db import connection, reset_queries
import pprint

# Import your models#
from main_app.models import ArtworkGallery

# Create and check models
# Run and print your queries

#note: 01_artwork_gallery
def show_highest_rated_art():
    art = ArtworkGallery.objects.order_by('-rating', 'id').first()

    return f"{art.art_name} is the highest_rated art with a {art.rating} rating!"

def bulk_create_arts(artwork_1, artwork_2):
    ArtworkGallery.objects.bulk_create([artwork_1, artwork_2])

def delete_negative_rated_arts():
    ArtworkGallery.objects.filter(rating__lt=0).delete()

# artwork1 = ArtworkGallery(artist_name='Vincent van Gogh', art_name='Starry Night',
# rating=4, price=1200000.0)
# artwork2 = ArtworkGallery(artist_name='Leonardo da Vinci', art_name='Mona Lisa',
# rating=5, price=1500000.0)

# Bulk saves the instances
# bulk_create_arts(artwork1, artwork2)
# print(show_highest_rated_art())
# print(ArtworkGallery.objects.all())
# delete_negative_rated_arts()
# print(connection.queries)