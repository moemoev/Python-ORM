import os
import django

from django.template.library import TagHelperNode


# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from django.db import connection, reset_queries
from django.db.models import Case, When, Value, CharField
import pprint

# Import your models#
from main_app.models import ArtworkGallery, Laptop


# Create and check models
# Run and print your queries

#note: 01_artwork_gallery
def show_highest_rated_art() -> str:
    art = ArtworkGallery.objects.order_by('-rating', 'id').first()

    return f"{art.art_name} is the highest_rated art with a {art.rating} rating!"

def bulk_create_arts(artwork_1, artwork_2) -> None:
    ArtworkGallery.objects.bulk_create([artwork_1, artwork_2])

def delete_negative_rated_arts() -> None:
    ArtworkGallery.objects.filter(rating__lt=0).delete()

# artwork1 = ArtworkGallery(artist_name='Vincent van Gogh', art_name='Starry Night',
# rating=4, price=1200000.0)
# artwork2 = ArtworkGallery(artist_name='Leonardo da Vinci', art_name='Mona Lisa',
# rating=5, price=1500000.0)

# Bulk saves the instances
# bulk_create_arts(artwork1, artwork2)
# print(show_highest_rated_art())
# print(ArtworkGallery.objects.all())
# delete_negative_rated_arts()
# print(connection.queries)

#note: 02_laptop
BRANDS_512_GB_STORAGE = ["Asus", "Lenovo"]
BRANDS_16_GB_MEMORY = ["Apple", "Dell", "Acer"]

def show_the_most_expensive_laptop() -> str:
    laptop = Laptop.objects.order_by('-price', '-id').first()

    return f"{laptop.brand} is the most expensive laptop available for {laptop.price}$!"

def bulk_create_laptops(args: list[Laptop]) -> None:
    Laptop.objects.bulk_create(args)

def update_to_512_GB_storage() -> None:
    Laptop.objects.filter(brand__in=BRANDS_512_GB_STORAGE).update(storage=512)

def update_to_16_GB_memory() -> None:
    Laptop.objects.filter(brand__in=BRANDS_16_GB_MEMORY).update(memory=16)

def update_operation_systems() -> None:
    Laptop.objects.update(
        operation_system=Case(
            When(brand="Asus", then=Value("Windows")),
            When(brand="Apple", then=Value("MacOS")),
            When(brand__in=["Dell", "Acer"], then=Value("Linux")),
            When(brand="Lenovo", then=Value("ChromeOS")),
            output_field=CharField(),
        )
    )

def delete_inexpensive_laptops():
    Laptop.objects.filter(price__lt=1200).delete()

# print(show_the_most_expensive_laptop())
# print(connection.queries)
#update_to_512_GB_storage()
#update_to_16_GB_memory()
#update_operation_systems()
# delete_inexpensive_laptops()
# print(connection.queries)