from django.contrib import admin

from main_app.models import ChessPlayer, Dungeon, Workout, Meal, ArtworkGallery, Laptop


# Register your models here.
@admin.register(ChessPlayer)
class ChessPlayerAdmin(admin.ModelAdmin):
    list_display = (
        "username",
        "title",
        "rating",
        "games_played",
        "games_won",
        "games_lost",
        "games_drawn",
    )

    list_filter = ("title",)
    search_fields = ("username", "title")
    ordering = ("-rating",)

    fieldsets = (
        ("Player Information", {
            "fields": ("username", "title", "rating"),
        }),
        ("Statistics", {
            "fields": (
                "games_played",
                "games_won",
                "games_lost",
                "games_drawn",
            ),
        }),
    )

@admin.register(Meal)
class MealAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "meal_type",
        "chef",
        "difficulty",
        "calories",
        "preparation_time",
    )

    list_filter = ("meal_type", "difficulty")
    search_fields = ("name", "chef")
    ordering = ("name",)

    fieldsets = (
        ("Basic Information", {
            "fields": ("name", "meal_type", "chef"),
        }),
        ("Recipe Details", {
            "fields": (
                "preparation_time",
                "difficulty",
                "calories",
            ),
        }),
    )

@admin.register(Dungeon)
class DungeonAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "difficulty",
        "location",
        "boss_name",
        "recommended_level",
        "boss_health",
    )

    list_filter = ("difficulty",)
    search_fields = ("name", "boss_name", "location")
    ordering = ("recommended_level",)

    fieldsets = (
        ("Dungeon", {
            "fields": (
                "name",
                "difficulty",
                "location",
            ),
        }),
        ("Boss", {
            "fields": (
                "boss_name",
                "boss_health",
                "recommended_level",
            ),
        }),
        ("Rewards", {
            "fields": ("reward",),
        }),
    )

@admin.register(Workout)
class WorkoutAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "workout_type",
        "difficulty",
        "duration",
        "calories_burned",
        "instructor",
    )

    list_filter = ("workout_type", "difficulty")
    search_fields = ("name", "instructor")
    ordering = ("name",)

    fieldsets = (
        ("Workout", {
            "fields": (
                "name",
                "workout_type",
                "difficulty",
            ),
        }),
        ("Session Details", {
            "fields": (
                "duration",
                "calories_burned",
                "instructor",
            ),
        }),
    )

@admin.register(ArtworkGallery)
class ArtworkGalleryAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "art_name",
        "artist_name",
        "rating",
        "price",
    )

    list_filter = ("rating",)
    search_fields = (
        "art_name",
        "artist_name",
    )
    ordering = ("-rating", "price")

    fieldsets = (
        ("Artwork Information", {
            "fields": (
                "art_name",
                "artist_name",
            ),
        }),
        ("Details", {
            "fields": (
                "rating",
                "price",
            ),
        }),
    )

@admin.register(Laptop)
class LaptopAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "brand",
        "processor",
        "memory",
        "storage",
        "operation_system",
        "price",
    )

    list_filter = (
        "brand",
        "operation_system",
        "memory",
        "storage",
    )

    search_fields = (
        "brand",
        "processor",
    )

    ordering = ("-price",)

    readonly_fields = ("id",)

    fieldsets = (
        ("Laptop Information", {
            "fields": (
                "id",
                "brand",
                "processor",
            ),
        }),
        ("Specifications", {
            "fields": (
                "memory",
                "storage",
                "operation_system",
            ),
        }),
        ("Pricing", {
            "fields": ("price",),
        }),
    )

    list_per_page = 20
    save_on_top = True