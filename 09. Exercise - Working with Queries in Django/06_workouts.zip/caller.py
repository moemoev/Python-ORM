import os
import django
from django.db.models.sql import Query

from django.template.library import TagHelperNode


# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from django.db import connection, reset_queries
from django.db.models import Case, When, Value, CharField, PositiveIntegerField, F, TextField, QuerySet
import pprint

# Import your models#
from main_app.models import ArtworkGallery, Laptop, ChessPlayer, Meal, Dungeon, Workout


# Create and check models
# Run and print your queries

#note: 01_artwork_gallery
def show_highest_rated_art() -> str:
    art = ArtworkGallery.objects.order_by('-rating', 'id').first()

    return f"{art.art_name} is the highest_rated art with a {art.rating} rating!"

def bulk_create_arts(artwork_1, artwork_2) -> None:
    ArtworkGallery.objects.bulk_create([artwork_1, artwork_2])

def delete_negative_rated_arts() -> None:
    ArtworkGallery.objects.filter(rating__lt=0).delete()

# artwork1 = ArtworkGallery(artist_name='Vincent van Gogh', art_name='Starry Night',
# rating=4, price=1200000.0)
# artwork2 = ArtworkGallery(artist_name='Leonardo da Vinci', art_name='Mona Lisa',
# rating=5, price=1500000.0)

# Bulk saves the instances
# bulk_create_arts(artwork1, artwork2)
# print(show_highest_rated_art())
# print(ArtworkGallery.objects.all())
# delete_negative_rated_arts()
# print(connection.queries)

#note: 02_laptop
BRANDS_512_GB_STORAGE = ["Asus", "Lenovo"]
BRANDS_16_GB_MEMORY = ["Apple", "Dell", "Acer"]

def show_the_most_expensive_laptop() -> str:
    laptop = Laptop.objects.order_by('-price', '-id').first()

    return f"{laptop.brand} is the most expensive laptop available for {laptop.price}$!"

def bulk_create_laptops(args: list[Laptop]) -> None:
    Laptop.objects.bulk_create(args)

def update_to_512_GB_storage() -> None:
    Laptop.objects.filter(brand__in=BRANDS_512_GB_STORAGE).update(storage=512)

def update_to_16_GB_memory() -> None:
    Laptop.objects.filter(brand__in=BRANDS_16_GB_MEMORY).update(memory=16)

def update_operation_systems() -> None:
    Laptop.objects.update(
        operation_system=Case(
     When(brand="Asus", then=Value("Windows")),
            When(brand="Apple", then=Value("MacOS")),
            When(brand__in=["Dell", "Acer"], then=Value("Linux")),
            When(brand="Lenovo", then=Value("ChromeOS")),
            output_field=CharField(),
        )
    )

def delete_inexpensive_laptops():
    Laptop.objects.filter(price__lt=1200).delete()

# print(show_the_most_expensive_laptop())
# print(connection.queries)
#update_to_512_GB_storage()
#update_to_16_GB_memory()
#update_operation_systems()
# delete_inexpensive_laptops()
# print(connection.queries)

#note: 03_chess_player

def bulk_create_chess_players(args: list[ChessPlayer]) -> None:
    ChessPlayer.objects.bulk_create(args)

def delete_chess_players() -> None:
    def_value = ChessPlayer._meta.get_field('title').default
    ChessPlayer.objects.filter(title=def_value).delete()

def change_chess_games_won() -> None:
    ChessPlayer.objects.filter(title="GM").update(games_won=30)

def change_games_lost() -> None:
    ChessPlayer.objects.filter(title="no title").update(games_lost=25)

def change_games_drawn() -> None:
    ChessPlayer.objects.update(games_drawn=10)

def grand_chess_title_GM() -> None:
    ChessPlayer.objects.filter(rating__gte=2400).update(title="GM")

def grand_chess_title_IM() -> None:
    ChessPlayer.objects.filter(rating__range=(2300, 2399)).update(title="IM")

def grand_chess_title_FM() -> None:
    ChessPlayer.objects.filter(rating__range=(2200, 2299)).update(title="FM")

def grand_chess_title_regular_player() -> None:
    ChessPlayer.objects.filter(rating__range=(0, 2199)).update(title="regular player")

# player1 = ChessPlayer(
#     username='Player1',
#     title='no title',
#     rating=2200,
#     games_played=50,
#     games_won=20,
#     games_lost=25,
#     games_drawn=5,
# )
#
# player2 = ChessPlayer(
#     username='Player2',
#     title='IM',
#     rating=2350,
#     games_played=80,
#     games_won=40,
#     games_lost=25,
#     games_drawn=15,
# )
# Call the bulk_create_chess_players function
# bulk_create_chess_players([player1, player2])
# Call the delete_chess_players
# function delete_chess_players(
# Check that the players are deleted print("Number of Chess Players after deletion:", ChessPlayer.objects.count())


#note: 04_meal

def set_new_chef() -> None:
    Meal.objects.update(
        chef=Case(
            When(meal_type="Breakfast", then=Value("Gordon Ramsey")),
            When(meal_type="Lunch", then=Value("Julia Child")),
            When(meal_type="Dinner", then=Value("Jamie Oliver")),
            When(meal_type="Snack", then=Value("Thomas Keller")),
            default=Value(''),
            output_field=CharField(),
        )
    )

def set_new_preparation_time() -> None:
    Meal.objects.update(
        preparation_time=Case(
            When(meal_type="Breakfast", then=Value("10 minutes")),
            When(meal_type="Lunch", then=Value("12 minutes")),
            When(meal_type="Dinner", then=Value("15 minutes")),
            When(meal_type="Snack", then=Value("5 minutes")),
            default=Value(''),
            output_field=CharField(),

        )
    )
LOW_CALORIE_MEALS=["Breakfast", "Dinner"]
HIGH_CALORIE_MEALS=["Lunch", "Snack"]

def update_low_calorie_meal() -> None:
    Meal.objects.filter(meal_type__in=LOW_CALORIE_MEALS).update(calories=400)

def update_high_calorie_meal() -> None:
    Meal.objects.filter(meal_type__in=HIGH_CALORIE_MEALS).update(calories=700)

def delete_lunch_and_snack_meals() -> None:
    Meal.objects.filter(meal_type__in=["Lunch", "Snack"]).delete()
#
# meal1 = Meal.objects.create(
# name="Pancakes",
# meal_type="Breakfast",
# preparation_time="20 minutes",
# difficulty=3,
# calories=350,
# chef="Jane",
# )
#
# meal2 = Meal.objects.create(
# name="Spaghetti Bolognese",
# meal_type="Dinner",
# preparation_time="45 minutes",
# difficulty=4,
# calories=550,
# chef="Sarah",
# )
# # Test the set_new_chefs function
# set_new_chefs()
# # Test the set_new_preparation_times function
# set_new_preparation_times()
# # Refreshes the instances
# meal1.refresh_from_db()
# meal2.refresh_from_db()
# # Print the updated meal information
# print("Meal 1 Chef:", meal1.chef)
# print("Meal 1 Preparation Time:", meal1.preparation_time)
# print("Meal 2 Chef:", meal2.chef)
# print("Meal 2 Preparation Time:", meal2.preparation_time)

#note: 05_dungeon

def show_hard_dungeons() -> str:
    dungeons = Dungeon.objects.filter(difficulty="Hard")

    return "\n".join(f"{d.name} is guarded by {d.boss_name} who has {d.boss_health} health points!" for d in dungeons)

def bulk_create_dungeons(args: list[Dungeon]) -> None:
    Dungeon.objects.bulk_create(args)

def update_dungeon_names() -> None:
    Dungeon.objects.update(
        name=Case(
            When(difficulty="Easy", then=Value("The Erased Thombs")),
            When(difficulty="Medium", then=Value("The Coral Labyrinth")),
            When(difficulty="Hard", then=Value("The Lost Haunt")),
            default=Value(''),
            output_field=CharField(),
        )
    )

def update_dungeon_bosses_health() -> None:
    Dungeon.objects.exclude(difficulty="Easy").update(boss_health=500)

def update_dungeon_recommended_levels() -> None:
    Dungeon.objects.update(
        recommended_level=Case(
            When(difficulty="Easy", then=Value("25")),
            When(difficulty="Medium", then=Value("50")),
            When(difficulty="Hard", then=Value("75")),
            default=Value('0'),
            output_field=PositiveIntegerField(),
        )
    )
def update_dungeon_rewards() -> None:
    Dungeon.objects.update(
        reward=Case(
            When(boss_health=500, then=Value("1000 Gold")),
            When(location__startswith="E", then=Value("New dungeon unlocked")),
            When(location__endswith="s", then=Value("Dragonheart Amulet")),
            default=Value(''),
            output_field=TextField(),
        )
    )

def set_new_locations() -> None:
    Dungeon.objects.update(
        location=Case(
            When(recommended_level=25, then=Value("Enchanted Maze")),
            When(recommended_level=50, then=Value("Grimstone Mines")),
            When(recommended_level=75, then=Value("Shadowed Abyss")),
            default=Value(""),
            output_field=CharField(),
        )
    )

# # Create two instances
# dungeon1 = Dungeon(
# name="Dungeon 1",
# boss_name="Boss 1",
# boss_health=1000,
# recommended_level=75,
# reward="Gold",
# location="Eternal Hell",
# difficulty="Hard",
# )
#
# dungeon2 = Dungeon(
# name="Dungeon 2",
# boss_name="Boss 2",
# boss_health=400,
# recommended_level=25,
# reward="Experience",
# location="Crystal Caverns",
# difficulty="Easy",
# )
# # Bulk save the instances
# bulk_create_dungeons([dungeon1, dungeon2])
#
# # Update boss's health
# update_dungeon_bosses_health()
#
# # Show hard dungeons
# hard_dungeons_info = show_hard_dungeons()
# print(hard_dungeons_info)
#
# # Change dungeon names based on difficulty
# update_dungeon_names()
# dungeons = Dungeon.objects.order_by('boss_health')
# print(dungeons[0].name)
# print(dungeons[1].name)
#
# # Change the dungeon rewards
# update_dungeon_rewards()
# dungeons = Dungeon.objects.order_by('boss_health')
# print(dungeons[0].reward)
# print(dungeons[1].reward)

#note: 06_workout

WORKOUT_TYPES_FILTER=["Calisthenics", "CrossFit"]

def show_workouts() -> str:
    workout = (Workout
               .objects
               .filter(workout_type__in=WORKOUT_TYPES_FILTER)
               .values('name', 'workout_type', 'difficulty')
               .order_by('id'))

    return '\n'.join(f"{w['name']} from {w['workout_type']} type has {w['difficulty']} difficulty!" for w in workout)

def get_high_difficulty_cardio_workouts() -> QuerySet[Workout]:
    workout = (Workout
               .objects
               .filter(workout_type="Cardio", difficulty="High")
               .order_by("id")
               )

    return workout

def set_new_instructors() -> None:
    Workout.objects.update(
        instructor=Case(
            When(workout_type="Cardio", then=Value("John Smith")),
            When(workout_type="Strength", then=Value("Michael Williams")),
            When(workout_type="Yoga", then=Value("Emily Johnson")),
            When(workout_type="CrossFit", then=Value("Sarah Davis")),
            When(workout_type="Calisthenics", then=Value("Chris Heria")),
            default=Value(""),
            output_field=CharField(),
        )
    )

def set_new_duration_times() -> None:
    Workout.objects.update(
        duration=Case(
            When(instructor="John Smith", then=Value("15 minutes")),
            When(instructor="Sarah Davis", then=Value("30 minutes")),
            When(instructor="Chris Heria", then=Value("45 minutes")),
            When(instructor="Michael Williams", then=Value("1 hour")),
            When(instructor="Emily Johnson", then=Value("1 hour and 30 minutes")),
            default=Value(''),
            output_field=CharField(),

        )
    )

def delete_workouts() -> None:
    Workout.objects.exclude(workout_type__in=["Strength", "Calisthenics"]).delete()

# Create two Workout instances
# workout1 = Workout.objects.create(
#     name="Push-Ups",
#     workout_type="Calisthenics",
#     duration="10 minutes",
#     difficulty="Intermediate",
#     calories_burned=200,
#     instructor="Bob"
# )
# workout2 = Workout.objects.create(
#     name="Running",
#     workout_type="Cardio",
#     duration="30 minutes",
#     difficulty="High",
#     calories_burned=400,
#     instructor="Lilly"
# )
#
# # Run the functions
# print(show_workouts())
#
# high_difficulty_cardio_workouts = get_high_difficulty_cardio_workouts()
# for workout in high_difficulty_cardio_workouts:
#     print(f"{workout.name} by {workout.instructor}")
#
# set_new_instructors()
# for workout in Workout.objects.all():
#     print(f"Instructor: {workout.instructor}")
#
# set_new_duration_times()
# for workout in Workout.objects.all():
#     print(f"Duration: {workout.duration}")
