from django.db import models

# Create your models here.
class Employee(models.Model):
    first_name = models.CharField(
        max_length=40
    )
    last_name = models.CharField(
        max_length=40
    )
    age = models.IntegerField()
    city = models.ForeignKey(to='City', on_delete=models.CASCADE)
    salary = models.IntegerField()
    gender = models.CharField(
        max_length=20
    )
    department = models.CharField(
        max_length=40
    )

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

class City(models.Model):
    name = models.CharField(
        max_length=40
    )

    def __str__(self):
        return self.name

class Lecturer(models.Model):
    first_name = models.CharField(
        max_length=100
    )
    last_name = models.CharField(
        max_length=100
    )

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

class Subject(models.Model):
    name = models.CharField(
        max_length=100
    )
    code = models.CharField(
        max_length=10
    )
    lecturer = models.ForeignKey(
        to='Lecturer',
        on_delete=models.SET_NULL,
        null=True
    )

    def __str__(self):
        return f"{self.name}"


class Student(models.Model):
    student_id = models.CharField(max_length=10, primary_key=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    birth_date = models.DateField()
    email = models.EmailField(unique=True)
    subjects = models.ManyToManyField(to='Subject', through='StudentEnrollment')



class StudentEnrollment(models.Model):
    class GradeChoices(models.TextChoices):
        A = 'A', 'A'
        B = 'B', 'B'
        C = 'C', 'C'
        D = 'D', 'D'
        f = 'F', 'F'
    
    student = models.ForeignKey(to='Student', on_delete=models.CASCADE)
    subject = models.ForeignKey(to="Subject", on_delete=models.CASCADE)
    enrollment_date = models.DateField(auto_now_add=True)
    grade = models.CharField(max_length=1, choices=GradeChoices.choices)

