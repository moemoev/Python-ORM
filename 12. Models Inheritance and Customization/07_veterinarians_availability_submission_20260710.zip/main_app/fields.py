from django.db import models


class BooleanChoiceField(models.BooleanField):
    CHOICES = [
        (True, "Available"),
        (False, "Not Available"),
    ]

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("choices", self.CHOICES)
        kwargs.setdefault("default", True)
        super().__init__(*args, **kwargs)