from django.db import models

from main_app.fields import CharacterCharField


# Create your models here.

class BaseCharacter(models.Model):
    name = CharacterCharField()
    description = models.TextField()

    class Meta:
        abstract = True

class Mage(BaseCharacter):
    elemental_power = CharacterCharField()
    spellbook_type = CharacterCharField()

class Assassin(BaseCharacter):
    weapon_type = CharacterCharField()
    assassination_technique = CharacterCharField()

class DemonHunter(BaseCharacter):
    weapon_type = CharacterCharField()
    demon_slaying_ability = CharacterCharField()

class TimeMage(Mage):
    time_magic_mastery = CharacterCharField()
    temporal_shift_ability = CharacterCharField()

class Necromancer(Mage):
    raise_dead_ability = CharacterCharField()


class ViperAssassin(Assassin):
    venomous_strike_mastery = CharacterCharField()
    venomous_bite_ability = CharacterCharField()

class ShadowbladeAssassin(Assassin):
    shadowstep_ability = CharacterCharField()


class VengeanceDemonHunter(DemonHunter):
    vengeance_mastery = CharacterCharField()
    retribution_ability = CharacterCharField()

class FelbladeDemonHunter(DemonHunter):
    felblade_ability = CharacterCharField()
