from django.db import models
from django.dispatch import receiver

from main_app.fields import CharacterCharField


# Create your models here.

class BaseCharacter(models.Model):
    name = CharacterCharField()
    description = models.TextField()

    class Meta:
        abstract = True

class Mage(BaseCharacter):
    elemental_power = CharacterCharField()
    spellbook_type = CharacterCharField()

class Assassin(BaseCharacter):
    weapon_type = CharacterCharField()
    assassination_technique = CharacterCharField()

class DemonHunter(BaseCharacter):
    weapon_type = CharacterCharField()
    demon_slaying_ability = CharacterCharField()

class TimeMage(Mage):
    time_magic_mastery = CharacterCharField()
    temporal_shift_ability = CharacterCharField()

class Necromancer(Mage):
    raise_dead_ability = CharacterCharField()


class ViperAssassin(Assassin):
    venomous_strike_mastery = CharacterCharField()
    venomous_bite_ability = CharacterCharField()

class ShadowbladeAssassin(Assassin):
    shadowstep_ability = CharacterCharField()


class VengeanceDemonHunter(DemonHunter):
    vengeance_mastery = CharacterCharField()
    retribution_ability = CharacterCharField()

class FelbladeDemonHunter(DemonHunter):
    felblade_ability = CharacterCharField()

class UserProfile(models.Model):
    username = models.CharField(
        max_length=70,
        unique=True,
    )
    email = models.EmailField(
        unique=True,
    )
    bio = models.TextField(
        null=True,
        blank=True,
    )

class Message(models.Model):
    sender = models.ForeignKey(
        to='UserProfile',
        related_name='sent_messages',
        on_delete=models.CASCADE,
    )
    receiver = models.ForeignKey(
        to='UserProfile',
        related_name='received_messages',
        on_delete=models.CASCADE,
    )
    content = models.TextField()
    timestamp = models.DateField(
        auto_now_add=True,
    )
    is_read = models.BooleanField(
        default=False,
    )

    def mark_as_read(self) -> None:
        self.is_read = True

    def reply_to_message(self, reply_content: str) -> 'Message':
        new_message = Message.objects.create(
            sender=self.receiver,
            receiver=self.sender,
            content=reply_content,
        )
        new_message.save()

        return new_message

    def forward_message(self, receiver: UserProfile) -> 'Message':
        new_message = Message.objects.create(
            sender=self.receiver,
            receiver=receiver,
            content=self.content,
        )
        new_message.save()

        return new_message
