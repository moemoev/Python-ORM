from django.core.exceptions import ValidationError
from django.db import models

class CharacterCharField(models.CharField):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault("max_length", 100)
        super().__init__(*args, **kwargs)

class StudentIDField(models.PositiveIntegerField):
    def to_python(self, value):
        return int(value)

    def get_prep_value(self, value):

        try:
            self.to_python(value=value)
        except ValueError:
            raise ValueError("Invalid input for student ID")

        if value <=0:
            raise ValidationError("ID cannot be less than or equal to zero")

        return value