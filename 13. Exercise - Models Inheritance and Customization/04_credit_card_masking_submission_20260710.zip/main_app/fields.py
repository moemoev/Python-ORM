from django.core.exceptions import ValidationError
from django.db import models

class CharacterCharField(models.CharField):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault("max_length", 100)
        super().__init__(*args, **kwargs)

class StudentIDField(models.PositiveIntegerField):
    def to_python(self, value):
        return int(value)

    def get_prep_value(self, value):

        try:
            self.to_python(value=value)
        except ValueError:
            raise ValueError("Invalid input for student ID")

        if value <=0:
            raise ValidationError("ID cannot be less than or equal to zero")

        return value

class MaskedCreditCardField(models.CharField):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault("max_length", 20)
        super().__init__(*args, **kwargs)

    def to_python(self, value):
        if not isinstance(value, str):
            raise ValidationError("The card number must be a string")

        if any(not ch.isdigit() for ch in value):
            raise ValidationError("The card number must contain only digits")

        if not len(value) == 16:
            raise ValidationError("The card number must be exactly 16 characters long")

        return  '****-****-****-' + value[-4::]