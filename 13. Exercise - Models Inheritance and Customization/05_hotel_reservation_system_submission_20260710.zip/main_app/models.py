from datetime import timedelta

from django.core.exceptions import ValidationError
from django.db import models
from psycopg2._psycopg import Decimal

from main_app.fields import CharacterCharField, StudentIDField, MaskedCreditCardField


# Create your models here.

class BaseCharacter(models.Model):
    name = CharacterCharField()
    description = models.TextField()

    class Meta:
        abstract = True

class Mage(BaseCharacter):
    elemental_power = CharacterCharField()
    spellbook_type = CharacterCharField()

class Assassin(BaseCharacter):
    weapon_type = CharacterCharField()
    assassination_technique = CharacterCharField()

class DemonHunter(BaseCharacter):
    weapon_type = CharacterCharField()
    demon_slaying_ability = CharacterCharField()

class TimeMage(Mage):
    time_magic_mastery = CharacterCharField()
    temporal_shift_ability = CharacterCharField()

class Necromancer(Mage):
    raise_dead_ability = CharacterCharField()


class ViperAssassin(Assassin):
    venomous_strike_mastery = CharacterCharField()
    venomous_bite_ability = CharacterCharField()

class ShadowbladeAssassin(Assassin):
    shadowstep_ability = CharacterCharField()


class VengeanceDemonHunter(DemonHunter):
    vengeance_mastery = CharacterCharField()
    retribution_ability = CharacterCharField()

class FelbladeDemonHunter(DemonHunter):
    felblade_ability = CharacterCharField()

class UserProfile(models.Model):
    username = models.CharField(
        max_length=70,
        unique=True,
    )
    email = models.EmailField(
        unique=True,
    )
    bio = models.TextField(
        null=True,
        blank=True,
    )

class Message(models.Model):
    sender = models.ForeignKey(
        to='UserProfile',
        related_name='sent_messages',
        on_delete=models.CASCADE,
    )
    receiver = models.ForeignKey(
        to='UserProfile',
        related_name='received_messages',
        on_delete=models.CASCADE,
    )
    content = models.TextField()
    timestamp = models.DateField(
        auto_now_add=True,
    )
    is_read = models.BooleanField(
        default=False,
    )

    def mark_as_read(self) -> None:
        self.is_read = True

    def reply_to_message(self, reply_content: str) -> 'Message':
        new_message = Message.objects.create(
            sender=self.receiver,
            receiver=self.sender,
            content=reply_content,
        )
        new_message.save()

        return new_message

    def forward_message(self, receiver: UserProfile) -> 'Message':
        new_message = Message.objects.create(
            sender=self.receiver,
            receiver=receiver,
            content=self.content,
        )
        new_message.save()

        return new_message

class Student(models.Model):
    name = models.CharField(
        max_length=100
    )
    student_id = StudentIDField()

class CreditCard(models.Model):
    card_owner = models.CharField(
        max_length=100,
    )
    card_number = MaskedCreditCardField()

class Hotel(models.Model):
    name = models.CharField(
        max_length=100,
    )
    address = models.CharField(
        max_length=200,
    )

class Room(models.Model):
    hotel = models.ForeignKey(
        to='Hotel',
        on_delete=models.CASCADE,
    )
    number = models.CharField(
        max_length=100,
        unique=True,
    )
    capacity = models.PositiveIntegerField()
    total_guests = models.PositiveIntegerField()
    price_per_night = models.DecimalField(
        max_digits=10,
        decimal_places=2,
    )
    def clean(self) -> None:
        if self.total_guests > self.capacity:
            raise ValidationError("Total guests are more than the capacity of the room")

    def save(self, *args, **kwargs) -> str:
        self.clean()
        super().save(*args, **kwargs)

        return f"Room {self.number} created successfully"

class BaseReservation(models.Model):
    class Meta:
        abstract = True

    room = models.ForeignKey(
        to='Room',
        on_delete=models.CASCADE,
    )
    start_date = models.DateField()
    end_date = models.DateField()

    def clean(self) ->None:
        if self.start_date >= self.end_date:
            raise ValidationError("Start date cannot be after or in the same end date")


        if self.__class__.objects.filter(room=self.room).filter(start_date__lte=self.end_date, end_date__gte=self.start_date).exists():
            raise ValidationError(f"Room {self.room.number} cannot be reserved")

    @property
    def reservation_type(self) -> str:
        raise NotImplemented

    def save(self, *args, **kwargs) -> str:
        self.clean()
        super().save(*args, **kwargs)

        return f"{self.reservation_type} reservation for room {self.room.number}"

    @property
    def stay_in_days(self):
        return (self.end_date - self.start_date).days

    def reservation_period(self) -> int:
        return self.stay_in_days

    def calculate_total_cost(self) -> Decimal:
        calculated_price = self.stay_in_days * self.room.price_per_night
        return round(calculated_price, 2)

class RegularReservation(BaseReservation):
    @property
    def reservation_type(self) -> str:
        return "Regular"

class SpecialReservation(BaseReservation):
    @property
    def reservation_type(self) -> str:
        return "Special"

    def extend_reservation(self,days: int) -> str:
        new_end_date = self.end_date + timedelta(days=days)

        if self.__class__.objects.filter(room=self.room).filter(start_date__lte=new_end_date, end_date__gte=self.start_date).exists():
            raise ValidationError(f"Error during extending reservation")

        self.end_date = new_end_date
        self.save()

        return f"Extended reservation for room {self.room.number} with {days} days"