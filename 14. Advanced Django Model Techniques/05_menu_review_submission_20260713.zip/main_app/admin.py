from django.contrib import admin
from main_app.models import RegularRestaurantReview,FoodCriticRestaurantReview
# Register your models here.

@admin.register(RegularRestaurantReview)
class AdminRegularRestaurantReview(admin.ModelAdmin):
    list_display = ["reviewer_name", "review_content", "rating"]


@admin.register(FoodCriticRestaurantReview)
class AdminFoodCriticRestaurantReview(admin.ModelAdmin):
    list_display = ["reviewer_name", "review_content", "rating"]